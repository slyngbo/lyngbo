<footer id="footer" class="container-fluid text-center">
  <div class="row">

    <div class="col-md-6 col-sm-6 col-lg-4">
      <div>
        <h2>Contact us</h2></div>
        <div class="footer-line"></div>
      <div>
        <h4 id="footermail">Vestergadekaffe@gmail.com</h4>
      </div>
        <div class="footer-icons"> <a href="http://www.findsmiley.dk/527733"><i class="fa fa-smile-o fa-3x" aria-hidden="true"></i></a></div>
          <h6 class="text-muted">See our Elite-smiley</h6>
    </div>
    <div class="col-md-6 col-sm-6 col-lg-4">
      <div>
        <h2>Find us</h2></div>
        <div class="footer-line"></div>
          <div><h4>Vestergade 58 Aarhus, Denmark</h4></div>

      <div class="footer-icons">
        <a href="https://www.facebook.com/billscoffee/" class="fa fa-facebook fa-3x fa-fw"></a>
        <a href="https://www.instagram.com/billscoffee/" class="fa fa-instagram fa-3x fa-fw"></a>
      </div>
    </div>
    <div class="col-md-12 col-sm-12 col-lg-4">
      <h2>Opening hours</h2>
      <div class="footer-line"></div>
      <div>
        <h4>Monday-Friday: 07:30-18:00</h4></div>
      <div>
        <h4 class="p-3">Saturday: 09:00-18:00</h4></div>
      <div>
        <h4>Sunday: 09:00-17:00</h4></div>
    </div>
    <div class="col">
      <div class="copyrights text-muted">
        <h6>&copy;Copyrights 2018 - Bill's Coffee</h6>
        <a href="#" class="scrollup"><i class="fa fa-arrow-circle-up fa-3x pull-end"> </i></a>
      </div>

    </div>
  </div>
</footer>

<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'aarhus-bryghus');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@C{|X[{Z_NU(E?=}7u785ha?C N?.x;(C[ew|5-;/4Yv.3+#[~$7Uf4yuu;,yvV:');
define('SECURE_AUTH_KEY',  '2)*/@c8HojI)F^_PNX<)w[zS33Vp7_oUHfWY)gjfR<m-EHYkd6V0}+Mup`VfxC`*');
define('LOGGED_IN_KEY',    'l6Cq^rSuJ(NeUz`sZ*D;7O>3jE3e|@S_.cOnj[GB*}>: QpK8gLrp9`G1eoN >^*');
define('NONCE_KEY',        '[4v1R2+T/y}Q|iC~w(fbx2Y*BPA3p#cFzFN94bX3k=:-}#!=a]x?0#q0a9:bvC%u');
define('AUTH_SALT',        'yy*oz5B7!h6AGMvr7btTIdop5RO=g;=x{w/3LIJxcxjd7[X7`IA5+Kq/MZ/oYO<8');
define('SECURE_AUTH_SALT', '2%9l3`9n2?p/N;%6Cjy:5-vcf+c,@^*MyrR{$c)*LUC 5#:vn%YT)5!nd /x6zh5');
define('LOGGED_IN_SALT',   'w-=YmYQL$`slPH-kjij=;dm.Qip^GD`g{KqprXC|LdaN(m-,>`/Zw~xQyIdkB+E^');
define('NONCE_SALT',       '$C Qh/+} 2`L|EWJ20n:@f0;KcFQv^KQ4trflK)3c!-o=|]W=1Z.2$A_0CF7:1x3');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

<?php>
var_dump($_get);<?>

<h1><?php>echo $_GET["category"]<?> </h1>
